module.exports = {
    publicPath: '/'
}